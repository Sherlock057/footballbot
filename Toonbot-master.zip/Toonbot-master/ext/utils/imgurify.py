from imgurpython import ImgurClient
from io import cStringIO
import json

# def imgurify(image):
#	file = cStringIO()
#	file.write(image)
#	with open('credentials.json') as f:
#		credentials = json.load(f)
#	imgur = ImgurClient(credentials["Imgur"]["Authorization"],["Imgur"]["Secret"])
